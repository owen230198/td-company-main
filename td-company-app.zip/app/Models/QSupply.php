<?php
 
namespace App\Models;
 
use Illuminate\Database\Eloquent\Model;
 
class QSupply extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'q_supplies';
    protected $protectFields = false;
}
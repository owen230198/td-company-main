<?php
    namespace App\Models;
    use Illuminate\Database\Eloquent\Model;
    class PSubstance extends Model
    {
        protected $table = 'p_substances';
        protected $protectFields = false;
    }
    
?>
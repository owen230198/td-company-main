<?php
 
namespace App\Models;
 
use Illuminate\Database\Eloquent\Model;
 
class QFinish extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'q_finishes';
    protected $protectFields = false;
}
<div class="modalAction modal fade" id="actionModal" tabindex="-1" role="dialog" aria-labelledby="actionModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content position-relative">
      <button type="button" class="close_action_popup" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
      <div class="modal-body">
        <iframe class="iframe_action_view" src="" width="100%" frameborder="0" sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-top-navigation" allowtransparency="true">
          
        </iframe>
      </div>
    </div>
  </div>
</div>
@php
	$name = $field['name']; 
@endphp
<p class="mb-0 limit_line_1 text-center color_red">{{ number_format((int)$data[$name]) }} đ</p>
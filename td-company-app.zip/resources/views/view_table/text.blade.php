@php
	$name = $field['name']; 
@endphp
<p class="mb-0">{{ $data[$name] }}</p>
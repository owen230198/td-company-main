<div class="section_quote_print_paper">
    <div class="list_paper_config">
        <div class="quote_paper_item item_main">
            @include('quotes.products.papers.ajax_view')
        </div>    
    </div>
    <div class="text-center my-3">
        <button type="button" data-product="{{ $j }}" class="main_button color_white bg_green border_green radius_5 font_bold sooth add_print_paper_quote_button">
            <i class="fa fa-plus mr-2 fs-14" aria-hidden="true"></i> Thêm tờ in
        </button>
    </div> 
</div>